function Hello(){
    console.log('Hello');
}
var setT= setInterval(Hello,500);
function stop(){
    console.log("Executed 10 times");
    clearInterval(setT);
}
setTimeout(stop,5500);
