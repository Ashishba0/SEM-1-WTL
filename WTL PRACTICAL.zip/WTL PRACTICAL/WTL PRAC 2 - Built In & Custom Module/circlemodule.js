exports.message="Circle"
exports.area=function(r){return Math.PI*r*r;}
exports.peri=function(r){return 2*Math.PI*r;}
