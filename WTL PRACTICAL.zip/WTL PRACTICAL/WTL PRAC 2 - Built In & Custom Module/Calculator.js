var dt= require("./calcmodule.js");
console.log("Calculator:" +dt.message);
console.log("Addition:" +dt.add(20,10));
console.log("Subtraction:" +dt.subtract(20,10));
console.log("Multiplication:" +dt.multiply(20,10));
console.log("Division:" +dt.divide(20,0));
