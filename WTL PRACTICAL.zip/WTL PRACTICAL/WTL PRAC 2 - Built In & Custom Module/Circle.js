var dt = require("./CustomCircle");
console.log(dt.message);
console.log("Area of Circle with radius 5 = " +dt.area(5));	
console.log("Perimeter of Circle with radius 4 = " +dt.peri(4));
