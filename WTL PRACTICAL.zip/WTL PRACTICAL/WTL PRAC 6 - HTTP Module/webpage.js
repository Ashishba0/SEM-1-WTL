var http = require('http');
var fs = require('fs');
var server = http.createServer(function (req, res) {
    if (req.url === '/') {
        // Home Page
        fs.readFile('HomePage.html', (err, data) => {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write(data);
            res.end();
        });

    } else if (req.url === '/aboutus') {
        // Route to About Me
        fs.readFile('AboutUs.html', (err, data) => {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write(data);
            res.end();
        });

    } else if (req.url === '/contact') {
        // Route to Contact
        fs.readFile('Contact.html', (err, data) => {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write(data);
            res.end();
        });

    } else {
        res.writeHead(404);
        res.end();
    }
});

server.listen(5000);
