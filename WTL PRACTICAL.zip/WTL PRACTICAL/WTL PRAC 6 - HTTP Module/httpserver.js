const http = require('http');
const fs = require('fs');
 
const server = http.createServer((req, res) => {
  if (req.url === '/') {
    // Serve an HTML file
    fs.readFile('index.html', (err, data) => {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.write(data);
      res.end();
    });
  } else if (req.url === '/data.csv') {
    // Serve a CSV file
    fs.readFile('data.csv', (err, data) => {
      res.writeHead(200, { 'Content-Type': 'text/csv' });
      res.write(data);
      res.end();
    });
  } else if (req.url === '/data.json') {
    // Serve a JSON file
    fs.readFile('data.json', (err, data) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.write(data);
      res.end();
    });
  } else if (req.url === '/document.pdf') {
    // Serve a PDF file
    fs.readFile('document.pdf', (err, data) => {
      res.writeHead(200, { 'Content-Type': 'application/pdf' });
      res.write(data);
      res.end();
    });
  } else {
    // If the request is for a different URL, return a 404 error
    res.writeHead(404);
    res.end();
  }
});
 
server.listen(3000);
