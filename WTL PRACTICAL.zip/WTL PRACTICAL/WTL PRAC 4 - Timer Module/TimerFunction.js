let num = process.argv[2]

//Multiplication Table
process.nextTick(function(){
   	 	for(let i=0; i<=10; i++){
        			console.log(num+"*"+i+"="+i*num);
    		}
});
 
//Leap Year
var leap = setInterval(function(){
    		if((num%4==0)&&(num%100!=0)||(num%400==0)){
        			console.log("Year "+num+" is a leap year");
   		 }
    		else{
        			console.log("Year "+num+" is not a leap year");
    		}
},1000);
 
let timeout = setTimeout(function(){
    		clearInterval(leap);
},6000);
 
//Palindrome
function reverseString(num){
   		 let rev = "";
    		for(let i=num.length; i>=0; i--){
        			rev+=num.charAt(i);    
   		 }
   		 return rev;
}
let revStr=reverseString(num);
var pal = setImmediate(function(){
   	 	if(num==revStr){
      		  	console.log(num+' is a Palindrome');
    		}
    		else{
        			console.log(num+' is not a Palindrome');
    		}
});
