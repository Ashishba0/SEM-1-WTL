//leap year program
let timerId = setImmediate(leap,2002);
    function leap(year){
        if((year%4 ==0) && (year%100 != 0) || (year%400==0))
    {
        console.log(+year+ "  is a leap year...");
    }
    else{
        console.log(+year+"  is not a leap year")
    }
}
//multiplication program
const process = require('process');
function multiply(num)
{
    for(let i =1; i<11; i++){
        console.log(num+ " * " +i+ " = " +num*i);
    }    
}
process.nextTick(multiply,8);

//palindrome program

function pallindrome(string)
{
   let len = string.length;
   for(let i=0; i<(len/2) ;i++)
   {
      if (string[i] !== string[len-1-i])
      {
        console.log('It is not a pallindrome');
      }
   }
      console.log('It is a pallindrome');
}
myInterval = setInterval(pallindrome,1991,"nayan");
setTimeout(()=>{
    clearInterval(myInterval);
},3000)
