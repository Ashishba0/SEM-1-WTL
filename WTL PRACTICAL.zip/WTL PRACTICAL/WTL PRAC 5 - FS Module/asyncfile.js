let fs = require('fs');
let rl = require('readline-sync');


console.log("Asynchronous Operations");


console.log("\n[Write File]");
let content = rl.question("Enter the content you would like to enter in the file: ");
fs.writeFile('File_A.txt', content, (err) => {
    if (err) {
        console.error(err);
    }
});
console.log("File Written Successfully");


var read = setImmediate(function () {
    console.log("\n[Read File]");
    fs.readFile('File_A.txt', function (err, data) {
        if (err) return console.error(err);
        console.log("Contents of File: " + data.toString());
    });
    console.log("File Read Successfully");
});


var append = setInterval(function () {
    console.log("\n[Append File]");
    data = fs.readFileSync('File_B.txt');
    fs.appendFile('File_A.txt', data, (err) => {
        if (err) {
            console.error(err);
        }
        fs.readFile('File_A.txt', function (err, data) {
            if (err) return console.error(err);
            console.log("Contents of File: " + data.toString());
        });
    });
    console.log("File Appended Successfully");
}, 1000);


let timeout_append = setTimeout(function () {
    clearInterval(append);
}, 1001);


var rename = setInterval(function () {
    console.log("\n[Rename File]");
    fs.renameSync('File_A.txt', 'File_C.txt', (err) => {
        if (err) {
            console.error(err);
        }
    });
    console.log("File Renamed Successfully");
}, 2000);


let timeout_rename = setTimeout(function () {
    clearInterval(rename);
}, 2001);


var del = setInterval(function () {
    console.log("\n[Delete File]");
    fs.unlink('File_C.txt', (err) => {
        if (err) {
            console.error(err);
        }
    });
    console.log("File Deleted Successfully");
}, 3000);


let timeout_delete = setTimeout(function () {
    clearInterval(del);
}, 3001);
