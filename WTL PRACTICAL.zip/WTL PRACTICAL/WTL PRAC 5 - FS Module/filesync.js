let fs = require('fs');
let rl = require('readline-sync');
 
console.log("Synchronous Operations");
console.log("1. Write File");
console.log("2. Read File");
console.log("3. Append File");
console.log("4. Rename File");
console.log("5. Delete File");
console.log("6. Exit");
let ch;
do {
    ch = rl.questionInt("\nEnter your choice:")
    switch(ch) {
        case 1:
            console.log('Write File');
            let content = rl.question("Enter the content you would like to enter in the file: ");
            fs.writeFileSync('input.txt',content);
            console.log("File Written Successfully");
            break;
        case 2:
            console.log('Read File');
            console.log('Contents of File: '+fs.readFileSync('input.txt'));
            console.log("File Read Successfully");
            break;
        case 3:
            console.log('Append File');
            var data = "APPENDING THE FILE SYNCHRONOUSLY"; 
            fs.appendFileSync('input.txt',data);
            console.log("File Appended Successfully");
            break;
        case 4:
            console.log('Rename File');
            fs.renameSync('input.txt','io.txt');
            console.log("File Renamed Successfully");
            break;
        case 5:
            console.log('Delete File');
            fs.unlinkSync('io.txt');
            console.log("File Deleted Successfully");
            break;
        case 6:
            console.log("Exited Successfully")
            break;
    }
}while(ch!=6);
