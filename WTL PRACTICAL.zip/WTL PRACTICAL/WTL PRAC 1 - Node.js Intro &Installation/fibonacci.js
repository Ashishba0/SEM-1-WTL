let num = parseInt(process.argv[2]);
let n1=0,n2=1;
let fibstr= " ";
fibstr += n1+" ";
fibstr += n2+" ";
for (let i=n2;i<num-1;i++){
    let val=n1+n2;
    n1=n2;
    n2=val;
    fibstr+= val + " ";
}
console.log(fibstr);
