const arr = [] 
for(var n=2;n<=100;n++){ 
  for(var i=2;i<n;i++ ){
    if(n%i == 0){ 													
      break															
    }															
  }																	
  if(n == i){   
    arr.push(n)
  }
}
console.log(arr)
