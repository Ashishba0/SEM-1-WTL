n=5;
string="";
for (i=1;i<=n;i++){
    for(j=1;j<=n-i+1;j++){
        string += j +" ";
    }
    string+="\n";
}
console.log(string);
