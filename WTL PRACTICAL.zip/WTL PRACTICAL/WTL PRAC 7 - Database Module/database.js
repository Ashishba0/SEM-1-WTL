import { createConnection } from "mysql";


const printTable = (arr, fields) => {
    let colNames = '';
    for (const entry of fields) {
        colNames += '\t' + entry.name;
    }
    console.log(colNames);
    for (const ele of arr) {
        let row = '';
        for (const prop in ele) {
            row += '\t' + ele[prop];
        }
        console.log(row);
    }
}


const getConnection = (connConf, msg) => {
    const conn = createConnection(connConf);
    return new Promise((resolve, reject) => {
        conn.connect((err) => {
            if (err) reject(err.toString());
            else {
                console.log(msg);
                resolve(conn);
            }
        });
    });
}


const runQueryAndReport = (conn, queryStr, successMsg, hasToPrintTable = false) => {
    return new Promise((resolve, reject) => {
        conn.query(queryStr, (err, results, fields) => {
            if (err) reject(console.log(err.toString()));
            else {
                console.log(successMsg)
                if (hasToPrintTable) {
                    printTable(results, fields);
                }
                resolve();
            }
        });
    });
}


const config = {
    host: "localhost",
    user: "root",
    password: "",
    database: 'students'
};
const preDBConfig = JSON.parse(JSON.stringify(config));
delete preDBConfig.database;


const createDB = (conn) => {
    const databaseName = config['database'];
    const queryStr = `
		CREATE DATABASE ${databaseName};
		`;
    return runQueryAndReport(conn, queryStr, 'Database created successfully');
}
const createTable = (conn) => {
    const queryStr = `
		CREATE TABLE prasanna_students(roll_no INT PRIMARY KEY,
			name VARCHAR(20),
			address VARCHAR(50),
			contact_no VARCHAR(12),
			dept VARCHAR(20)
		);
		`;
    return runQueryAndReport(conn, queryStr, 'Table created successfully');
}
const insertTenRecords = (conn) => {
    const queryStr = `
		INSERT INTO prasanna_students VALUES ?;
		`;
    const values = [
        [1, 'prasanna', 'Nerul', '9769326135', 'MCA'],
        [2, 'Nahez', 'Panvel', '8125467845', 'CS'],
        [3, 'Rishabh', 'Dharavi', '7853277227', 'AI'],
        [4, 'Joseph', 'Mau Mui', '8754654254', 'ML'],
        [5, 'Kritaka', 'Nerul', '8965745457', 'MECH'],
        [6, 'Naved', 'Juhu', '9798793542', 'DS'],
        [7, 'Ilyas', 'Thane', '8175421213', 'IT'],
        [8, 'Rubina', 'Kurla', '8121347982', 'AI'],
        [9, 'Shreya', 'Ulhasnagar', '7486956145', 'AI'],
        [10, 'Pratik', 'Koparkhairane', '9769654213', 'MECH']
    ];
    return new Promise((resolve, reject) => {
        conn.query(queryStr, [values], (err, results) => {
            if (err) reject(console.log(err.toString()));
            else {
                resolve(console.log(results.affectedRows + ' records were inserted'));
            }
        });
    });
}


const updateARecord = (conn) => {
    const queryStr = `
		UPDATE prasanna_students SET roll_no=11 WHERE roll_no=1;
		`;
    return runQueryAndReport(conn, queryStr, 'Updated record successfully');
}


const deleteARecord = (conn) => {
    const queryStr = `
		DELETE FROM prasanna_students WHERE roll_no=11;
		`;
    return runQueryAndReport(conn, queryStr, 'Deleted record successfully');
}


const displayAllRecords = (conn) => {
    const queryStr = `
		SELECT * FROM prasanna_students;
		`;
    return runQueryAndReport(conn, queryStr, 'Display of all records:-', true);
}


const orderByName = (conn) => {
    const queryStr = `
		SELECT * FROM prasanna_students
			ORDER BY name;
		`;
    return runQueryAndReport(conn, queryStr, 'Records ordered by name:-', true);
}


const run = async () => {
    try {
        const preDBConn = await getConnection(preDBConfig, 'Connected to MySQL before creating database');
        await createDB(preDBConn);
        preDBConn.end();
        const conn = await getConnection(config, 'Connected to MySQL after creating database');
        await createTable(conn);
        await insertTenRecords(conn);
        await updateARecord(conn);
        await deleteARecord(conn);
        await displayAllRecords(conn);
        await orderByName(conn);
        conn.end();
    }
    catch (err) {
        console.log('Something odd happend:' + err);
    }
    finally {
        console.log('Program ended');
    }
}


run();
