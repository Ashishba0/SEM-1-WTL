var events = require('events');
var eventEmitter = new events.EventEmitter();
 
const numbers=[8, 20, 40, 5, 89, 101, 10];
const words=['Prasanna', 'Ghanshyam', 'Riddesh', 'Abhishek', 'Nahez'];
 
console.log("Sorting array of strings: ");
 
var sortStringMethod = function(arr){
    console.log("Sorted Array:"+arr.sort());
    console.log("Reverse Array:"+arr.reverse());
};
eventEmitter.on("Event-1",sortStringMethod);
eventEmitter.emit("Event-1",words);
 
console.log("\nSorting array of numbers:");
 
var sortNumberMethod = function(arr){
    arr.sort(function(a,b){return a - b});
    console.log("Sorted Array:"+arr);
    console.log("Reversed Array:"+arr.reverse());
 
};
eventEmitter.on("Event-2",sortNumberMethod);
eventEmitter.emit("Event-2",numbers);
 
var searchArray = function(arr,key) {
    var check=0;
    for(var i=0;i<arr.length;i++){
        if(arr[i]==key){
            check=1;
            break;}
        }
        if(check==1){
            console.log(key+" is found at position: "+(i+1));
 
        }
        else{
            console.log(key+"is not found ");
        }
    };
 
    console.log("\nArray of strings: " +words.toString());
    eventEmitter.on("Event-3",searchArray);
    eventEmitter.emit("Event-3",words,"Prasanna");
    eventEmitter.emit("Event-3",words,"Riddesh");
 
    console.log("\nArray of numbers: "+numbers.toString());
    eventEmitter.emit("Event-3",numbers,"101");
    eventEmitter.emit("Event-3",numbers,"20");


